var app = getApp();
Component({
  properties: {
    evaluate: {
      type: Number,
      value:0,
    },
    cartInfo:{
      type:Object,
      value:[],
    },
    orderId:{
      type:String,
      value:'',
    },
  },
  data: {
  },
  methods: {
  }
})